let formulario = document.getElementById('miFormulario');
let mensaje = document.getElementById('mensaje');
let enviarNombre = document.querySelector('.enviar');

enviarNombre.addEventListener('click', function(event) {
  event.preventDefault(); 
  let nombreUsuario = document.getElementById('nombreUsuario').value;
  mensaje.textContent = `¡Hola, ${nombreUsuario}! Bienvenid@ a tu página de café de confianza`;
});